from django.urls import path
from . import views
from django.contrib import admin
from django.urls import path, include


app_name = 'matrimony'

urlpatterns = [
    # Home Page
    path('', views.home, name='home'),

    # Authentication
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register_view, name='register'),

    # Profile Management
    path('create-profile/', views.create_profile, name='create_profile'),
    path('view-profile/', views.view_profile, name='view_profile'),
    path('my-profile/', views.my_profile, name='my_profile'),


    # Search & Favorites
    path('search/', views.search_profiles, name='search_profiles'),
    path('toggle-favorite/', views.toggle_favorite, name='toggle_favorite'),
    path('my-favorites/', views.my_favorites, name='favorites'),

    # Notifications
    path('notifications/', views.notifications, name='notifications'),

    # Chat & Messaging (Only available for premium users)
    path('chat/<int:user_id>/', views.chat, name='chat'),
    path('inbox/', views.inbox, name='inbox'),
    path('chat/delete/<int:message_id>/', views.delete_message, name='delete_message'),

    # Success Stories
    path('success-stories/', views.success_stories, name='success_stories'),
    
   path('delete-success-story/<int:pk>/', views.delete_success_story, name='delete_success_story'),

    # Premium Membership
    path('premium/', views.premium_dashboard, name='premium_dashboard'),
    path('premium/activate/', views.activate_premium, name='activate_premium'),

    path('upload-payment/', views.payment_upload, name='payment_upload'),

    path('user-profile/<int:user_id>/', views.view_user_profile, name='view_user_profile'),
      



  
]
