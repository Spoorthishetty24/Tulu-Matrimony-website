from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.http import JsonResponse, HttpResponseForbidden
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
from datetime import date, timedelta

from .models import (
    SuccessStory, Profile, Favorite, Notification,
    Message, PremiumMembership, ProfileView
)
from .forms import (
    SuccessStoryForm, UserRegisterForm, ProfileForm,
    PaymentRequestForm
)

# -------------------- AUTH --------------------

def home(request):
    bg_images = [f'bg{i}.jpg' for i in range(1, 10)]
    return render(request, 'matrimony/index.html', {'bg_images': bg_images})

def login_view(request):
    if request.method == 'POST':
        user = authenticate(
            request,
            username=request.POST.get('username'),
            password=request.POST.get('password')
        )
        if user:
            login(request, user)
            return redirect('matrimony:home')
        messages.error(request, "Invalid username or password")
    return render(request, 'matrimony/login.html')

def logout_view(request):
    logout(request)
    return redirect('matrimony:login')

def register_view(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('matrimony:create_profile')
        messages.error(request, "Please correct the errors below.")
    else:
        form = UserRegisterForm()
    return render(request, 'matrimony/register.html', {'form': form})

# -------------------- PREMIUM --------------------

def is_premium_user(user):
    try:
        membership = PremiumMembership.objects.get(user=user)
        return membership.is_premium and membership.end_date >= timezone.now()
    except PremiumMembership.DoesNotExist:
        return False

@login_required
def activate_premium(request):
    now = timezone.now()
    end = now + timedelta(days=30)
    membership, _ = PremiumMembership.objects.get_or_create(user=request.user)
    membership.is_premium = True
    membership.start_date = now
    membership.end_date = end
    membership.save()
    messages.success(request, "You are now a premium member.")
    return redirect('matrimony:premium_dashboard')

@login_required
def premium_dashboard(request):
    membership = PremiumMembership.objects.filter(user=request.user).first()
    return render(request, 'matrimony/premium_dashboard.html', {
        'membership': membership,
        'is_premium': is_premium_user(request.user)
    })

# -------------------- PROFILE --------------------

@login_required
def create_profile(request):
    profile = get_object_or_404(Profile, user=request.user)
    form = ProfileForm(request.POST or None, request.FILES or None, instance=profile)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, "Profile completed successfully.")
        return redirect('matrimony:view_profile')
    return render(request, 'matrimony/create_profile.html', {'form': form})

@login_required
def view_profile(request):
    profile = get_object_or_404(Profile, user=request.user)
    return render(request, 'matrimony/view_profile.html', {
        'profile': profile,
        'is_premium_user': is_premium_user(request.user)
    })

@login_required
def view_user_profile(request, user_id):
    target_user = get_object_or_404(User, id=user_id)
    profile = get_object_or_404(Profile, user=target_user)

    if request.user != target_user:
        ProfileView.objects.get_or_create(viewer=request.user, viewed=target_user)
        profile.view_count += 1
        profile.save()

    return render(request, 'matrimony/view_profile.html', {
        'profile': profile,
        'is_premium_user': is_premium_user(request.user)
    })

@login_required
def my_profile(request):
    profile = Profile.objects.filter(user=request.user).first()
    if not profile:
        return redirect('matrimony:create_profile')
    return render(request, 'matrimony/my_profile.html', {'profile': profile})

# -------------------- SEARCH & FAVORITES --------------------

@login_required
def search_profiles(request):
    profiles = Profile.objects.exclude(user=request.user)
    filters = {
        'caste__icontains': request.GET.get('caste'),
        'gender__iexact': request.GET.get('gender'),
        'profession__icontains': request.GET.get('profession'),
        'location__icontains': request.GET.get('location'),
    }
    filters = {k: v for k, v in filters.items() if v}
    profiles = profiles.filter(**filters)

    today = date.today()
    age_min = request.GET.get('age_min')
    age_max = request.GET.get('age_max')

    if age_min:
        max_birth = today - timedelta(days=int(age_min) * 365)
        profiles = profiles.filter(date_of_birth__lte=max_birth)
    if age_max:
        min_birth = today - timedelta(days=int(age_max) * 365)
        profiles = profiles.filter(date_of_birth__gte=min_birth)

    # Prioritize opposite gender
    user_gender = getattr(request.user.profile, 'gender', None)
    if user_gender == 'Female':
        male_profiles = profiles.filter(gender='Male')
        others = profiles.exclude(gender='Male')
        profiles = list(male_profiles) + list(others)
    elif user_gender == 'Male':
        female_profiles = profiles.filter(gender='Female')
        others = profiles.exclude(gender='Female')
        profiles = list(female_profiles) + list(others)
    else:
        profiles = list(profiles)

    user_fav_ids = Favorite.objects.filter(user=request.user).values_list('profile_id', flat=True)

    return render(request, 'matrimony/search_profiles.html', {
        'profiles': profiles,
        'user_fav_ids': list(user_fav_ids)
    })

@login_required
@csrf_exempt
def toggle_favorite(request):
    if request.method == 'POST':
        profile_id = request.POST.get('profile_id')
        try:
            profile = Profile.objects.get(id=profile_id)
            fav, created = Favorite.objects.get_or_create(user=request.user, profile=profile)
            if created:
                Notification.objects.create(
                    recipient=profile.user,
                    sender=request.user,
                    message=f"{request.user.username} added you to favorites ❤️"
                )
                return JsonResponse({'status': 'added', 'message': 'Added to favorites ❤️'})
            else:
                fav.delete()
                return JsonResponse({'status': 'removed', 'message': 'Removed from favorites 💔'})
        except Profile.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'Profile not found'})
    return JsonResponse({'status': 'error', 'message': 'Invalid request'})

@login_required
def my_favorites(request):
    favorites = Favorite.objects.filter(user=request.user).select_related('profile')
    return render(request, 'matrimony/favorites.html', {'favorites': favorites})

@login_required
def notifications(request):
    notifs = Notification.objects.filter(recipient=request.user).order_by('-created_at')
    return render(request, 'matrimony/notifications.html', {'notifications': notifs})

def unread_notifications(request):
    count = 0
    if request.user.is_authenticated:
        count = Notification.objects.filter(recipient=request.user, is_read=False).count()
    return {'unread_count': count}

# -------------------- INBOX & CHAT (Premium Only) --------------------

@login_required
def inbox(request):
    sent_to = Message.objects.filter(sender=request.user).values_list('receiver', flat=True)
    received_from = Message.objects.filter(receiver=request.user).values_list('sender', flat=True)
    user_ids = set(sent_to) | set(received_from)
    partners = User.objects.filter(id__in=user_ids).exclude(id=request.user.id)
    return render(request, 'matrimony/inbox.html', {
        'partners': partners,
        'is_premium_user': is_premium_user(request.user)
    })

@login_required
def chat(request, user_id):
    receiver = get_object_or_404(User, id=user_id)
    profile = get_object_or_404(Profile, user=receiver)

    if not is_premium_user(request.user):
        messages.warning(request, "Only premium members can initiate chat.")
        return redirect('matrimony:inbox')

    if request.method == "POST":
        content = request.POST.get('message')
        if content:
            Message.objects.create(sender=request.user, receiver=receiver, content=content)
        return redirect('matrimony:chat', user_id=user_id)

    messages_qs = Message.objects.filter(
        sender__in=[request.user, receiver],
        receiver__in=[request.user, receiver]
    ).order_by('timestamp')

    return render(request, 'matrimony/chat.html', {
        'receiver': receiver,
        'messages': messages_qs,
        'profile': profile,
        'is_premium_user': is_premium_user(request.user)
    })

@login_required
def delete_message(request, message_id):
    msg = get_object_or_404(Message, id=message_id)
    if msg.sender != request.user:
        return HttpResponseForbidden("You can't delete this message.")
    receiver_id = msg.receiver.id
    msg.delete()
    return redirect('matrimony:chat', user_id=receiver_id)

# -------------------- SUCCESS STORIES --------------------

@login_required
def success_stories(request):
    stories = SuccessStory.objects.all().order_by('-created_at')
    form = SuccessStoryForm()
    user_has_story = SuccessStory.objects.filter(user=request.user).exists()

    if request.method == 'POST' and not user_has_story:
        form = SuccessStoryForm(request.POST, request.FILES)
        if form.is_valid():
            story = form.save(commit=False)
            story.user = request.user
            story.save()
            messages.success(request, "Your success story has been added!")
            return redirect('matrimony:success_stories')

    return render(request, 'matrimony/success_story.html', {
        'stories': stories,
        'form': form,
        'user_has_story': user_has_story
    })

@login_required
def delete_success_story(request, pk):
    story = get_object_or_404(SuccessStory, pk=pk, user=request.user)
    story.delete()
    messages.success(request, "Your success story has been deleted.")
    return redirect('matrimony:success_stories')

# -------------------- PAYMENT --------------------

@login_required
def payment_upload(request):
    if request.method == 'POST':
        form = PaymentRequestForm(request.POST, request.FILES)
        if form.is_valid():
            payment = form.save(commit=False)
            payment.user = request.user
            payment.save()
            messages.success(request, "Your payment proof has been submitted. Please wait for admin approval.")
            return redirect('matrimony:view_profile')
    else:
        form = PaymentRequestForm()
    return render(request, 'matrimony/payment_upload.html', {'form': form})
