// // main.js – Reusable JS functions for navigation, alerts, and validation

// // Confirm logout functionality
// function confirmLogout() {
//   if (confirm("Are you sure you want to logout?")) {
//     // Redirect to logout URL or perform logout action
//     window.location.href = "/logout/"; // adjust URL if needed
//   }
// }

// // Smooth scroll to a section
// function scrollToSection(id) {
//   const element = document.getElementById(id);
//   if (element) {
//     element.scrollIntoView({ behavior: 'smooth' });
//   }
// }

// // Form input validation (basic example)
// function validateForm(formId) {
//   const form = document.getElementById(formId);
//   const inputs = form.querySelectorAll('input[required], textarea[required], select[required]');
//   let isValid = true;

//   inputs.forEach(input => {
//     if (!input.value.trim()) {
//       alert(`Please fill the ${input.name || input.id} field.`);
//       input.focus();
//       isValid = false;
//       return false;
//     }
//   });

//   return isValid;
// }

// // Auto background image slider
// let bgImages = ['bg1.jpg', 'bg2.jpg', 'bg3.jpg']; // Add your image names
// let currentBg = 0;
// function cycleBackground() {
//   document.body.style.backgroundImage = `url('static/images/${bgImages[currentBg]}')`;
//   currentBg = (currentBg + 1) % bgImages.length;
// }
// setInterval(cycleBackground, 10000); // Change background every 10 seconds

// // Navigation toggle (if using hamburger menu in mobile)
// function toggleNavMenu() {
//   const nav = document.querySelector("nav");
//   nav.classList.toggle("active");
// }

// // Flash message fade-out (if using Django messages)
// document.addEventListener('DOMContentLoaded', () => {
//   const flash = document.querySelector(".flash-message");
//   if (flash) {
//     setTimeout(() => {
//       flash.style.opacity = "0";
//       setTimeout(() => flash.remove(), 500);
//     }, 3000);
//   }
// });

const images = [
  "/static/bg1.jpg",
  "/static/bg2.jpg",
  "/static/bg3.jpg",
  "/static/bg4.jpg",
  "/static/bg5.jpg",
  "/static/bg6.jpg",
  "/static/bg7.jpg",
  "/static/bg8.jpg",
  "/static/bg9.jpg"
];

// Alternatively, dynamically generate URLs with Django static (if you need dynamic templating in JS, serve inline or use data attrs)

let currentIndex = 0;

function changeBackground() {
  document.body.style.backgroundImage = `url('${images[currentIndex]}')`;
  currentIndex = (currentIndex + 1) % images.length;
}

changeBackground();
setInterval(changeBackground, 2000);

const userName = localStorage.getItem("registeredName");
if (userName) {
  const introHeading = document.querySelector(".intro h2");
  if (introHeading) {
    introHeading.textContent = `Welcome, ${userName}!`;
  }
}


