from django.contrib import admin
from .models import PaymentRequest
from .models import (
    Profile,
    PremiumMembership,
    ProfileView,
    SuccessStory
)

# ✅ Register Profile with custom admin
@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'gender', 'location', 'is_boosted_display', 'view_count')

    def is_boosted_display(self, obj):
        return obj.is_boosted()
    is_boosted_display.short_description = "Boosted"

# ✅ Register PremiumMembership with custom admin
@admin.register(PremiumMembership)
class PremiumMembershipAdmin(admin.ModelAdmin):
    list_display = ('user', 'is_premium', 'start_date', 'end_date')

# ✅ Register ProfileView
admin.site.register(ProfileView)

# ✅ Register SuccessStory with custom admin
@admin.register(SuccessStory)
class SuccessStoryAdmin(admin.ModelAdmin):
    list_display = ('user', 'partner_name', 'title', 'created_at')
    search_fields = ('user__username', 'partner_name', 'title')



@admin.register(PaymentRequest)
class PaymentRequestAdmin(admin.ModelAdmin):
    list_display = ('user', 'payment_method', 'submitted_at', 'is_verified')
    list_filter = ('is_verified', 'payment_method')
    search_fields = ('user__username',)

