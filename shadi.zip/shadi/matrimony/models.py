from django.db import models
from django.contrib.auth.models import User
from datetime import date, timedelta
from django.utils import timezone
from django.db.models.signals import post_save
from django.dispatch import receiver

# Gender choices
GENDER_CHOICES = [
    ('Male', 'Male'),
    ('Female', 'Female'),
    ('Other', 'Other'),
]

def default_end_date():
    return timezone.now() + timedelta(days=30)

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100, default="Unknown")
    age = models.PositiveIntegerField(null=True, blank=True)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES, default='Male')
    height = models.CharField(max_length=10, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    phone = models.CharField(max_length=15, blank=True)
    location = models.CharField(max_length=100, blank=True)
    education = models.CharField(max_length=100, blank=True)
    profession = models.CharField(max_length=100, blank=True)
    religion = models.CharField(max_length=100, blank=True)
    caste = models.CharField(max_length=100, blank=True)
    subcaste = models.CharField(max_length=100, blank=True)
    bari = models.CharField(max_length=50, blank=True)
    rashi = models.CharField(max_length=50, blank=True)
    nakshatra = models.CharField(max_length=50, blank=True)

    bio = models.TextField(blank=True)
    photo = models.ImageField(upload_to='profile_photos/', null=True, blank=True)

    # Premium features
    boosted_until = models.DateTimeField(null=True, blank=True)
    view_count = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.user.username

    def get_age(self):
        if self.date_of_birth:
            today = date.today()
            return today.year - self.date_of_birth.year - (
                (today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day)
            )
        return self.age

    def is_boosted(self):
        return self.boosted_until and self.boosted_until >= timezone.now()

    @property
    def is_premium_user(self):
        return hasattr(self.user, 'premiummembership') and self.user.premiummembership.is_active()

class ProfileView(models.Model):
    viewer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='views_made')
    viewed = models.ForeignKey(User, on_delete=models.CASCADE, related_name='views_received')
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('viewer', 'viewed')

    def __str__(self):
        return f"{self.viewer.username} viewed {self.viewed.username}"
    
class Message(models.Model):
    sender = models.ForeignKey(User, related_name='sent_messages', on_delete=models.CASCADE)
    receiver = models.ForeignKey(User, related_name='received_messages', on_delete=models.CASCADE)
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False) 
   

    def __str__(self):
        return self.content[:50]

class Favorite(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    profile = models.ForeignKey(Profile, related_name='favorited_by', on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} favorites {self.profile.user.username}"

class Notification(models.Model):
    recipient = models.ForeignKey(User, related_name='notifications', on_delete=models.CASCADE)
    sender = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        sender_name = self.sender.username if self.sender else "System"
        return f"Notification for {self.recipient.username} from {sender_name}"

class SuccessStory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    partner_name = models.CharField(max_length=100)
    title = models.CharField(max_length=100)
    story = models.TextField()
    photo = models.ImageField(upload_to='success_photos/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} & {self.partner_name}"

class PremiumMembership(models.Model):
    PLAN_CHOICES = [
        ('Gold', 'Gold'),
        ('Platinum', 'Platinum'),
        ('Diamond', 'Diamond'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    is_premium = models.BooleanField(default=False)
    start_date = models.DateTimeField(default=timezone.now)
    end_date = models.DateTimeField(default=default_end_date)
    membership_type = models.CharField(max_length=20, choices=PLAN_CHOICES, default='Gold')

    def is_active(self):
        return self.is_premium and self.end_date >= timezone.now()

    def days_left(self):
        if self.is_active():
            return (self.end_date - timezone.now()).days
        return 0

    def __str__(self):
        return f"{self.user.username} - {self.membership_type} (Active: {self.is_active()})"


class PaymentRequest(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    screenshot = models.ImageField(upload_to='payment_screenshots/')
    payment_method = models.CharField(max_length=50, choices=[
        ('GPay', 'GPay'),
        ('Paytm', 'Paytm'),
        ('Bank', 'Bank Transfer'),
    ])
    submitted_at = models.DateTimeField(auto_now_add=True)
    is_verified = models.BooleanField(default=False)

    def __str__(self):
        return f"Payment by {self.user.username} - {self.payment_method} - Verified: {self.is_verified}"
    


@receiver(post_save, sender=PaymentRequest)
def activate_premium_on_verification(sender, instance, **kwargs):
    if instance.is_verified:
        from .models import PremiumMembership
        membership, created = PremiumMembership.objects.get_or_create(user=instance.user)
        membership.is_premium = True
        membership.start_date = timezone.now()
        membership.end_date = timezone.now() + timedelta(days=30)
        membership.membership_type = 'Gold'
        membership.save()

